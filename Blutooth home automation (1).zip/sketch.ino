// Project 2: Bluetooth Home Automation
// Wokwi simulation using Serial Monitor as Bluetooth input

const int lightPin = 8;
const int fanPin = 9;

void setup() {
  pinMode(lightPin, OUTPUT);
  pinMode(fanPin, OUTPUT);

  // Start serial communication
  Serial.begin(9600);

  // Initially keep both appliances OFF
  digitalWrite(lightPin, LOW);
  digitalWrite(fanPin, LOW);

  Serial.println("Bluetooth Home Automation");
  Serial.println("Commands:");
  Serial.println("1 - Light ON");
  Serial.println("0 - Light OFF");
  Serial.println("2 - Fan ON");
  Serial.println("3 - Fan OFF");
}

void loop() {

  if (Serial.available() > 0) {

    char command = Serial.read();

    if (command == '1') {
      digitalWrite(lightPin, HIGH);
      Serial.println("Light: ON");
    }

    else if (command == '0') {
      digitalWrite(lightPin, LOW);
      Serial.println("Light: OFF");
    }

    else if (command == '2') {
      digitalWrite(fanPin, HIGH);
      Serial.println("Fan: ON");
    }

    else if (command == '3') {
      digitalWrite(fanPin, LOW);
      Serial.println("Fan: OFF");
    }
  }
}